/*
=========================================================
 CloudPulse Dashboard JavaScript
=========================================================

This function obtains monitoring information from
the Flask API and updates the dashboard.

The API URL is:

/api/status
*/


async function updateDashboard() {

    try {

        // Request information from Flask API
        const response =
            await fetch("/api/status");


        // Convert response into JSON
        const data =
            await response.json();


        // ------------------------------------------------
        // UPDATE POD COUNT
        // ------------------------------------------------

        document.getElementById("pods")
            .innerText = data.pods;


        // ------------------------------------------------
        // UPDATE CPU
        // ------------------------------------------------

        document.getElementById("cpuText")
            .innerText = data.cpu + "%";


        document.getElementById("cpuBar")
            .style.width = data.cpu + "%";


        // ------------------------------------------------
        // UPDATE MEMORY
        // ------------------------------------------------

        document.getElementById("memoryText")
            .innerText = data.memory + "%";


        document.getElementById("memoryBar")
            .style.width = data.memory + "%";


        // ------------------------------------------------
        // UPDATE NETWORK
        // ------------------------------------------------

        document.getElementById("networkText")
            .innerText = data.network + "%";


        document.getElementById("networkBar")
            .style.width = data.network + "%";


        // ------------------------------------------------
        // UPDATE TIME
        // ------------------------------------------------

        document.getElementById("time")
            .innerText = data.timestamp;


        // ------------------------------------------------
        // SHOW CONTAINER / POD HOSTNAME
        // ------------------------------------------------

        document.getElementById("hostname")
            .innerText = data.hostname;

    }

    catch (error) {

        console.error(
            "Unable to fetch monitoring data:",
            error
        );
    }
}


/*
Run immediately when webpage loads.
*/

updateDashboard();


/*
Refresh monitoring information every 5 seconds.
*/

setInterval(
    updateDashboard,
    5000
);