# Import Flask for creating the web application
# render_template is used to display HTML files
# jsonify is used to return JSON data from API endpoints
from flask import Flask, render_template, jsonify

# socket helps us obtain the container/pod hostname
import socket

# datetime is used to show the current server time
from datetime import datetime


# Create the Flask application
app = Flask(__name__)


# ---------------------------------------------------------
# HOME ROUTE
# ---------------------------------------------------------
# This route displays our CloudPulse dashboard.
@app.route("/")
def home():

    # index.html is located inside the templates folder
    return render_template("index.html")


# ---------------------------------------------------------
# CLOUD STATUS API
# ---------------------------------------------------------
# This API provides data that is displayed on the dashboard.
#
# NOTE:
# CPU, memory and network values are simulated for
# demonstration purposes. They are NOT real Kubernetes
# resource metrics.
@app.route("/api/status")
def status():

    return jsonify({

        # Overall application health
        "status": "Healthy",

        # Number displayed on dashboard
        "pods": 2,

        # Simulated monitoring values
        "cpu": 42,
        "memory": 64,
        "network": 78,

        # Simulated cloud instance count
        "instances": 3,

        # Current server time
        "timestamp": datetime.now().strftime("%H:%M:%S"),

        # Very useful in Docker/Kubernetes because this
        # identifies the machine/container/pod serving request
        "hostname": socket.gethostname()
    })


# ---------------------------------------------------------
# HEALTH CHECK ENDPOINT
# ---------------------------------------------------------
# Kubernetes will use this endpoint for liveness and
# readiness probes.
@app.route("/health")
def health():

    return jsonify({
        "status": "healthy"
    }), 200


# ---------------------------------------------------------
# START APPLICATION
# ---------------------------------------------------------
# 0.0.0.0 allows the Flask application to be accessed
# from outside the container.
#
# Port 5000 is the application port.
if __name__ == "__main__":

    app.run(
        host="0.0.0.0",
        port=5000
    )